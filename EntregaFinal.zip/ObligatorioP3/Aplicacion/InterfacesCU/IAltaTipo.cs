﻿using Dominio.EntidadesDominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicacion.InterfacesCU
{
    public interface IAltaTipo
    {
        void Alta(Tipo t);
    }
}
