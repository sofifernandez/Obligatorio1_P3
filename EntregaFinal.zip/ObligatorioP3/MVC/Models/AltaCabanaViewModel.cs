﻿using Dominio.EntidadesDominio;

namespace MVC.Models
{
    public class AltaCabanaViewModel
    {
        public Cabana Cabana { get; set; }
        public IFormFile Foto { get; set; }

    }
}
